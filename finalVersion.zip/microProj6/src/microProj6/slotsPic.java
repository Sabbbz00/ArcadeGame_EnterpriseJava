package microProj6;

import javax.swing.*;

public class slotsPic extends JPanel{
	public slotsPic(){
		JLabel slot = new JLabel(new ImageIcon("/Users/Austin/Documents/JavaEnterprise/microProj6/src/Images/CasinoSlot.PNG"));
		this.add(slot);
	}
}
