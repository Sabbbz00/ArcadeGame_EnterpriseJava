package microProj6;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
public class DBToucher{
	public void addPoint(String userName)throws Exception{
		String driverName = "com.mysql.jdbc.Driver";
		Class.forName(driverName).newInstance();
		
		String conURL = "jdbc:mysql://10.48.10.126:3306/userscore";
		String user = "root";
		String pw = "sheridan";
		Connection con = DriverManager.getConnection(conURL, user, pw);
		
		Statement stm = (Statement) con.createStatement();
		String querySt = "  UPDATE user SET totalScore = totalScore + 1 WHERE userName=?";
		PreparedStatement ps = con.prepareStatement(querySt);
		ps.setString(1, userName);
		int res = ps.executeUpdate();
	}
	public String getTotalScore(String userName)throws Exception{
		String driverName = "com.mysql.jdbc.Driver";
		Class.forName(driverName).newInstance();
		
		String conURL = "jdbc:mysql://10.48.10.126:3306/userscore";
		String user = "root";
		String pw = "sheridan";
		Connection con = DriverManager.getConnection(conURL, user, pw);
		
		Statement stm = (Statement) con.createStatement();
		String querySt = "SELECT totalScore FROM user WHERE userName=?";
		PreparedStatement ps = con.prepareStatement(querySt);
		ps.setString(1, userName);
		ResultSet res = ps.executeQuery();
		String returnStatement = "";
		while(res.next()){
			returnStatement = res.getString(1);
		}
		return returnStatement;
	}
	public void enterNewUser(String userName, String password)throws Exception{
		String driverName = "com.mysql.jdbc.Driver";
		Class.forName(driverName).newInstance();
		
		String conURL = "jdbc:mysql://10.48.10.126:3306/userscore";
		String user = "root";
		String pw = "sheridan";
		Connection con = DriverManager.getConnection(conURL, user, pw);
		
		Statement stm = (Statement) con.createStatement();
		String querySt = "  INSERT into user(userName, passWord, totalScore)values(?, ?, 0);";
		PreparedStatement ps = con.prepareStatement(querySt);
		ps.setString(1, userName);
		ps.setString(2, password);
		int res = ps.executeUpdate();
				
	}
	
	public boolean loginUser(String userName, String password) throws Exception{
		String driverName = "com.mysql.jdbc.Driver";
		Class.forName(driverName).newInstance();
		
		String conURL = "jdbc:mysql://10.48.10.126:3306/userscore";
		String user = "root";
		String pw = "sheridan";
		Connection con = DriverManager.getConnection(conURL, user, pw);
		
		Statement stm = (Statement) con.createStatement();
		String querySt = " SELECT * FROM user WHERE userName=? AND password=?";
		PreparedStatement ps = con.prepareStatement(querySt);
		ps.setString(1, userName);
		ps.setString(2, password);
		ResultSet res = ps.executeQuery();
		boolean LoggedIn = false;
		int num = 0;
		while(res.next()){
			num++;
		}
		if(num ==0){
			JOptionPane.showMessageDialog(null, "This is not a valid login. Please try again.");
		}else{
			JOptionPane.showMessageDialog(null,"Login Succesful");
			LoggedIn = true;
		}
		
		stm.close();
		res.close();
		con.close();
		return LoggedIn;
	}
	public boolean checkUser(String userName) throws Exception{
		String driverName = "com.mysql.jdbc.Driver";
		Class.forName(driverName).newInstance();
		
		String conURL = "jdbc:mysql://10.48.10.126:3306/userscore";
		String user = "root";
		String pw = "sheridan";
		Connection con = DriverManager.getConnection(conURL, user, pw);
		
		Statement stm = (Statement) con.createStatement();
		String querySt = "SELECT * from user WHERE userName=?";
		PreparedStatement ps = con.prepareStatement(querySt);
		ps.setString(1, userName);
		ResultSet res = ps.executeQuery();
		int num = 0;
		boolean goodUserName = true;
		while(res.next()){
			System.out.println(res.getString(1) + " \t" + res.getString(2) + " \t" +
					res.getString(3));
			num++;
		}
		if(num != 0){
			JOptionPane.showMessageDialog(null, "This Username exists. Please enter a new one.");
			goodUserName = false;
		}else{
			JOptionPane.showMessageDialog(null, "New User is created. Please Login.");
		}
		stm.close();
		res.close();
		con.close();
		return goodUserName;
	}
}
