package microProj6;

public class mainClass {

	public static void main(String[] args) {
		mainPage newFrame = new mainPage();
	}

}