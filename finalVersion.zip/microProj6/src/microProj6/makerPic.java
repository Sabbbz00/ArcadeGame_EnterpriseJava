package microProj6;

import javax.swing.*;

public class makerPic extends JPanel{
	public makerPic(){
		JLabel maker = new JLabel(new ImageIcon("/Users/Austin/Documents/JavaEnterprise/microProj6/src/Images/casinoMaker.PNG"));
		this.add(maker);
	}
}
