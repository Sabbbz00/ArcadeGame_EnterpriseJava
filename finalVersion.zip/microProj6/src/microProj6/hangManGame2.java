package microProj6;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.*;

import javax.swing.*;

public class hangManGame2 extends JFrame implements ActionListener, Runnable {
	String userPlayer = "";
	JPanel gridPanel, drawPanel;
	ArrayList<JButton> list = new ArrayList<JButton>();
	JButton throwAway;
	hangManPen drawPen = new hangManPen();
	int chances = 10;
	int chosenNum;
	Thread testThread;
	Music newBar;
	File fr2 = null;
	int rerun;

	Toolkit tk = Toolkit.getDefaultToolkit();
	Dimension d = tk.getScreenSize();

	public hangManGame2(String UserPlaying) throws Exception {
		this.userPlayer = UserPlaying;
		fr2 = new File(("/Users/Austin/Documents/JavaEnterprise/microProj6/src/microProj6/Daniel.wav"));
		testThread = new Thread(this, "test");
		testThread.start();
		chosenNum = 1 + (int) (Math.random() * 100);
		System.out.println("Chosen Number: " + chosenNum);
		gridPanel = new JPanel();
		drawPanel = new JPanel();
		drawPanel.setBackground(Color.GRAY);
		drawPanel.add(drawPen);
		drawPanel.setVisible(true);
		gridPanel.setLayout(new GridLayout(10, 10));
		gridPanel.setSize(800, 800);
		for (int i = 1; i <= 100; i++) {
			throwAway = new JButton(Integer.toString(i));
			throwAway.setOpaque(true);
			// throwAway.setBorderPainted(false);
			list.add(throwAway);
			gridPanel.add(throwAway);
			throwAway.addActionListener(this);
		}
		// this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(new GridLayout(2, 2));
		this.add(gridPanel);
		// //this.add(drawPanel);
		// System.out.println("After draw panel");
		// this.add(drawPen);
		// System.out.println("After draw pen");
		// this.setSize(800, 420);
		// this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (Integer.parseInt(e.getActionCommand()) == chosenNum) {
			list.get(Integer.parseInt(e.getActionCommand()) - 1).setBackground(Color.green);
			try {
				newBar.stopSong();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "You Win!");
			DBToucher DBTouch = new DBToucher();
			try {
				DBTouch.addPoint(this.userPlayer);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			this.setVisible(false);
		} else {
			chances--;
			if (chances != 0) {
				drawPen = new hangManPen();
				this.add(drawPen);
				System.out.println("Chances left: " + chances);
				if (Integer.parseInt(e.getActionCommand()) < chosenNum) {
					list.get(Integer.parseInt(e.getActionCommand()) - 1).setBackground(Color.yellow);
				} else if (Integer.parseInt(e.getActionCommand()) > chosenNum) {
					list.get(Integer.parseInt(e.getActionCommand()) - 1).setBackground(Color.red);
				}
				repaint();
			} else {
				rerun++;
				drawPen = new hangManPen();
				this.add(drawPen);
				repaint();
				try {
					newBar.stopSong();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(null, "Game over");
				this.setVisible(false);
			}
		}
	}// actionPerformed

	@Override
	public void run() {
		try {
			Thread.sleep(500);
			// newBar = new PlayMusicProgressBar(fr2);
			// this.add(newBar);
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			// this.setLayout(new GridLayout(1,2));
			// this.add(gridPanel);
			// //this.add(drawPanel);
			System.out.println("After draw panel");
			this.add(drawPen);
			this.repaint();
			System.out.println("After draw pen");
			newBar = new Music(fr2);
			this.add(newBar);
			this.setSize((int) d.getWidth(), (int) d.getHeight());
			this.setVisible(true);
			newBar.iterate(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
